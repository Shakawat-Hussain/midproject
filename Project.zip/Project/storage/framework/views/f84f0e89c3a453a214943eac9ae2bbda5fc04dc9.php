
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
    <title>Edit</title>
    <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

    <h1>Editprofile</h1>

<form action="<?php echo e(route('editprofile.submit')); ?>" Method="post">
        <?php echo e(csrf_field()); ?>

       
        <div class="form-group">
   <label>First Name  :</label><input type="text"  name="first_name"><br>
 
</div>
  
    <div class="form-group">
    
    <label>Last Name  :</label><input type="text"  name="last_name"><br>
</div>    
  
     
    <div class="form-group">
   
    <label>MobileNo</label><input type="text"  name="mobileno"><br>
</div>   

    <br>
    <div class="form-group">
  
  <label>Department</label> <input type="text"  name="Department" ><br>
  </div>            

<br>
<input type="submit" value="Editprofile">

</form>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\Project\resources\views/Teacher/editprofile.blade.php ENDPATH**/ ?>
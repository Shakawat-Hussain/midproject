<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="<?php echo e(asset('css/teacher.css')); ?>">
</head>
<body>
    <div id="header"><ul><a href="<?php echo e(route('logout')); ?>">Logout</a>
    <li><a href="/sections">Sections</a></li>
    <li><a href="/schedule">Schedule</a></li>
    
    <li><a class="btn btn-primary" href="tprofile/edit">Edit Profile</a></li>
    <li class="dropdown"> <a href="javascript:void(0)" class="dropbtn">Settings</a>
    <div class="dropdown-content">
        <a href="/tprofile/settings/changepassword">Changepassword</a></li>
        <a href="/tprofile/theme">Theme</a></li>
</div>

</ul>
</div>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->yieldContent('stage2'); ?>
    <div id="footer">
    <a href="/login">Help</a>
    <a href="/login">___________________________________</a>
    <a href="/sections">Contact</a>
    
   



    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\Project\Project\resources\views/layout/static.blade.php ENDPATH**/ ?>
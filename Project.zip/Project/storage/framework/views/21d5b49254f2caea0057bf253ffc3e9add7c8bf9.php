<!DOCTYPE html>
<html>
    <title>Sign Up</title>
    <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <h1>Register Now</h1>
    <form action="<?php echo e(route('signup.submit')); ?>" Method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
    <label>First Name  :</label><input type="text" id="fname" name="first_name" value="<?php echo e(old('first_name')); ?>"><br>
</div>
    <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class="text-danger"><?php echo e($message); ?></span><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
    <div class="form-group">
    <label>Last Name  :</label><input type="text" id="lname" name="last_name" value="<?php echo e(old('last_name')); ?>"><br>
</div>    
    <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class="text-danger"><?php echo e($message); ?></span><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
    <div class="form-group">
    <label>UserName  :</label><input type="text" id="username" name="username" value="<?php echo e(old('username')); ?>"><br>
</div>    
    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class="text-danger"><?php echo e($message); ?></span><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
    <div class="form-group">
    <label>MobileNo</label><input type="text" id="mobno" name="mobileno" value="<?php echo e(old('mobileno')); ?>"><br>
</div>   
    <?php $__errorArgs = ['mobno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class="text-danger"><?php echo e($message); ?></span><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
    <label>Email  :</label><input type="text" id="userid" name="email" value="<?php echo e(old('email')); ?>"><br>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class="text-danger"><?php echo e($message); ?></span><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
    <label>Password</label><input type="text" id="password" name="password"><br>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class="text-danger"><?php echo e($message); ?></span><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
    <label>ConfirmPassword</label><input type="text" id="confirmpassword" name="confirmpassword"><br>
        <?php $__errorArgs = ['confirmpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class="text-danger"><?php echo e($message); ?></span><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
    <label>Gender</label> <input  type="radio"  name="gender" value="Male">
             <label>Male</label>
  
             <input type="radio"  name="gender" value="Female">
             <label>Female</label>
  
             <input type="radio"  name="gender" value="others">
             <label>Others</label> <br>
             <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class="text-danger"><?php echo e($message); ?></span><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
  <br>
  <label>Department</label> <input type="checkbox" id="choice" name="department" value="CSE">CSE
                   <input type="checkbox" id="choice" name="department" value="EEE">EEE
                   <input type="checkbox" id="choice" name="department" value="BBA">BBA
                   <input type="checkbox" id="choice" name="department" value="LAW">LAW

<br>

        <br>
<input type="file" name="filetoupload">
<br>
        
   
      
        <input type="submit" value="Signup">

</form>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\Project\Project\resources\views/account/signup.blade.php ENDPATH**/ ?>